#define F_CPU 1200000
#include <avr/io.h>
#include <util/delay.h>

int main()
{
	DDRC=0b0000000;
	DDRB=0b00011110;
	int ls, rs=0;
	while(1)
	
	{
		ls= PINC & 0b0000001;
		rs= PINC & 0b0000010;
		if((ls==0b0000001)&&(rs==0b0000010))
		{
			PORTB= 0b00010010;
		}
		if((ls==0b0000000)&&(rs==0b0000010))
		{
			PORTB= 0b00010000;
		}
		if((ls==0b0000001)&&(rs==0b0000000))
		{
			PORTB= 0b00000010;
		}
		if((ls==0b0000000)&&(rs==0b0000000))
		{
			PORTB= 0b00000000;
			
		
	}
	
	
	
}
}